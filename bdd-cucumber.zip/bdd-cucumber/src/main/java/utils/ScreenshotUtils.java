package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.io.File;
import java.io.IOException;

public class ScreenshotUtils {

    private WebDriver driver;

    public ScreenshotUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void takeScreenshot(String fileName) {
        // Cast the driver to TakesScreenshot
        TakesScreenshot ts = (TakesScreenshot) driver;
        
        // Capture the screenshot as a file
        File source = ts.getScreenshotAs(OutputType.FILE);
        
        // Specify the destination file path
        File destination = new File("target/screenshots/" + fileName + ".png");
        
        try {
            // Copy the file to the specified location
            FileUtils.copyFile(source, destination);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
