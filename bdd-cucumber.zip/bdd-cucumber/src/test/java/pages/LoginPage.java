package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utils.ScreenshotUtils;

public class LoginPage {
    
    private WebDriver driver;
    private ScreenshotUtils screenshotUtils;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.screenshotUtils = new ScreenshotUtils(driver);
    }

    public void openLoginPage() {
        driver.get("http://example.com/login");
        screenshotUtils.takeScreenshot("login_page");
    }

    public void enterCredentials(String username, String password) {
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("loginButton")).click();
        screenshotUtils.takeScreenshot("credentials_entered");
    }

    public boolean isLoggedIn() {
        boolean loggedIn = driver.findElement(By.id("logoutButton")).isDisplayed();
        screenshotUtils.takeScreenshot("logged_in");
        return loggedIn;
    }
}
